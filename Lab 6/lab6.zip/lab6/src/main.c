/**
 * Copyright (C) PlatformIO <contact@platformio.org>
 * See LICENSE for details.
 */

#include "ADC.h"
#include "LCD.h"


int main(void) {
  while (1) {
  }
  return 0;
}
